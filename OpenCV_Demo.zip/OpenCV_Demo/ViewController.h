//
//  ViewController.h
//  OpenCV_Demo
//
//  Created by 张昭 on 25/11/2016.
//  Copyright © 2016 张昭. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

